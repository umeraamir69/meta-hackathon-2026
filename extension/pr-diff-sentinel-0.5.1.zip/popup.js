const urlInput = document.querySelector('#url');
const state = document.querySelector('#state');
const message = document.querySelector('#message');
const report = document.querySelector('#report');
const form = document.querySelector('#scan');
const goBtn = document.querySelector('#go');
const foot = document.querySelector('#foot');
const full = document.querySelector('#full');
const dash = document.querySelector('#dash');
const picker = document.querySelector('#picker');
const pickList = document.querySelector('#pick-list');
const pickCount = document.querySelector('#pick-count');
const pickerHint = document.querySelector('#picker-hint');
const scanPicked = document.querySelector('#scan-picked');

const API_BASE = 'https://pr-diff-sentinel.vercel.app';
const GITHUB_RE = /^https:\/\/(www\.)?github\.com\/[^/\s]+\/[^/\s]+(\/.*)?$/;
const MAX_PICK = 5;
const SHOWN = 5;

const api = globalThis.chrome;
const selected = new Set();

function openDashboard() {
  const href = api?.runtime?.getURL ? api.runtime.getURL('dashboard.html') : 'dashboard.html';
  if (api?.tabs?.create) {
    api.tabs.create({ url: href });
    return;
  }
  window.open(href, '_blank', 'noopener,noreferrer');
}

async function tabUrl() {
  try {
    if (!api?.tabs?.query) return '';
    const tabs = await api.tabs.query({ active: true, currentWindow: true });
    const url = tabs[0]?.url || '';
    if (!/github\.com\/[^/]+\/[^/]+/.test(url)) return '';
    return url.split('#')[0].split('?')[0];
  } catch {
    return '';
  }
}

function show(text, kind) {
  message.textContent = text;
  message.className = kind || '';
}

function pretty(label) {
  return label ? String(label).replaceAll('_', ' ') : 'unlabeled';
}

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text != null) node.textContent = text;
  return node;
}

/**
 * Classify a GitHub URL for the popup.
 * - pr / commit → scan immediately
 * - repo (home, tree/blob on a branch, pulls list, etc.) → ask user to pick
 */
function classifyGitHubUrl(raw) {
  const trimmed = String(raw || '').trim();
  if (!GITHUB_RE.test(trimmed)) return { kind: 'none' };
  let url;
  try {
    url = new URL(trimmed);
  } catch {
    return { kind: 'none' };
  }
  const parts = url.pathname.split('/').filter(Boolean).map((part) => {
    try { return decodeURIComponent(part); } catch { return part; }
  });
  if (parts.length < 2) return { kind: 'none' };
  const owner = parts[0];
  const repo = parts[1].replace(/\.git$/i, '');
  const repoUrl = `https://github.com/${owner}/${repo}`;
  const third = parts[2] || '';
  const fourth = parts[3] || '';

  if ((third === 'pull' || third === 'pulls') && /^\d{1,10}$/.test(fourth)) {
    return {
      kind: 'pr',
      scanUrl: `https://github.com/${owner}/${repo}/pull/${fourth}`,
      repoUrl,
      label: `${owner}/${repo}#${fourth}`,
    };
  }

  if ((third === 'commit' || third === 'commits') && /^[0-9a-f]{7,40}$/i.test(fourth)) {
    return {
      kind: 'commit',
      scanUrl: `https://github.com/${owner}/${repo}/commit/${fourth}`,
      repoUrl,
      label: `${owner}/${repo}@${fourth.slice(0, 7)}`,
    };
  }

  // File / tree page pinned to a commit SHA → scan that commit.
  if ((third === 'blob' || third === 'tree') && /^[0-9a-f]{7,40}$/i.test(fourth)) {
    return {
      kind: 'commit',
      scanUrl: `https://github.com/${owner}/${repo}/commit/${fourth}`,
      repoUrl,
      label: `${owner}/${repo}@${fourth.slice(0, 7)}`,
      fromFile: true,
    };
  }

  // Repo home, branch tree/blob, /pulls, /issues, /actions, etc. → picker.
  return {
    kind: 'repo',
    scanUrl: repoUrl,
    repoUrl,
    label: `${owner}/${repo}`,
    context: third || 'home',
  };
}

function setBusy(on, label) {
  goBtn.disabled = on;
  scanPicked.disabled = on || selected.size === 0;
  if (on) {
    state.textContent = 'Scanning';
    state.className = 'scanning';
    goBtn.textContent = label || 'Scanning…';
  } else {
    goBtn.textContent = 'Scan';
  }
}

function hidePicker() {
  picker.hidden = true;
  pickList.replaceChildren();
  selected.clear();
  pickCount.textContent = `0/${MAX_PICK}`;
}

function updatePickCount() {
  pickCount.textContent = `${selected.size}/${MAX_PICK}`;
  scanPicked.disabled = selected.size === 0 || goBtn.disabled;
  scanPicked.textContent = selected.size
    ? `Scan ${selected.size} selected`
    : 'Scan selected';
}

function renderPicker(listing, page) {
  hidePicker();
  picker.hidden = false;
  const pulls = listing.pulls || [];
  const commits = listing.commits || [];
  const ctx = page?.context || 'home';
  if (ctx === 'blob' || ctx === 'tree') {
    pickerHint.textContent = 'You’re on a file/folder page. Pick a pull request or commit to scan — files alone are not a merge gate.';
  } else if (ctx === 'pulls') {
    pickerHint.textContent = 'Pick a pull request below (or a recent commit).';
  } else {
    pickerHint.textContent = 'This tab is the repo home. Choose a pull request or commit to scan.';
  }

  if (!pulls.length && !commits.length) {
    pickList.append(el('p', 'empty-pick', 'No public PRs or recent commits found.'));
    return;
  }

  function addGroup(title, items, kind) {
    if (!items.length) return;
    pickList.append(el('p', 'group-label', title));
    for (const item of items) {
      const row = el('label', 'pick-row');
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.value = item.url;
      box.addEventListener('change', () => {
        if (box.checked) {
          if (selected.size >= MAX_PICK) {
            box.checked = false;
            show(`Pick up to ${MAX_PICK} items.`, 'error');
            return;
          }
          selected.add(item.url);
        } else {
          selected.delete(item.url);
        }
        updatePickCount();
        show('');
      });
      const body = el('span', 'pick-body');
      if (kind === 'pull') {
        body.append(el('strong', '', `#${item.number} ${item.title || '(no title)'}`));
        body.append(el('span', 'pick-meta', `${item.state || 'open'} · ${item.author || 'unknown'}`));
      } else {
        body.append(el('strong', '', item.subject || '(no message)'));
        body.append(el('span', 'pick-meta', `${String(item.sha || '').slice(0, 7)} · ${item.author || 'unknown'}${item.date ? ` · ${item.date}` : ''}`));
      }
      row.append(box, body);
      pickList.append(row);
    }
  }

  addGroup('Pull requests', pulls, 'pull');
  addGroup('Recent commits', commits, 'commit');
  updatePickCount();
}

function badgesFor(finding) {
  const badges = [];
  if (finding.removed) badges.push({ text: 'removed', hot: false });
  if (finding.encoding) badges.push({ text: `encoded ${finding.encoding}`, hot: false });
  if (finding.presentInTree === false) badges.push({ text: 'deleted from current files', hot: true });
  return badges;
}

function encodePath(path) {
  return String(path || '').split('/').map((part) => encodeURIComponent(part)).join('/');
}

function githubFindingUrl(body, finding) {
  const owner = body.owner;
  const repo = body.repo;
  if (!owner || !repo) return null;
  const path = finding?.path || '';
  const line = finding?.line ? Number(finding.line) : null;
  const sha = finding?.commit || body.head || null;
  if (!path || path === 'commit-message' || path === 'commit' || path === 'pull-request') {
    if (sha) return `https://github.com/${owner}/${repo}/commit/${sha}`;
    if (body.pull) return `https://github.com/${owner}/${repo}/pull/${body.pull}`;
    return `https://github.com/${owner}/${repo}`;
  }
  if (sha) {
    const base = `https://github.com/${owner}/${repo}/blob/${sha}/${encodePath(path)}`;
    return line ? `${base}#L${line}` : base;
  }
  if (body.pull) return `https://github.com/${owner}/${repo}/pull/${body.pull}/files`;
  return null;
}

function render(body, url) {
  state.textContent = body.ok ? 'Pass' : 'Fail';
  state.className = body.ok ? 'pass' : 'fail';
  report.hidden = false;
  foot.hidden = false;
  report.replaceChildren();
  const findings = (body.findings || []).filter((finding) => !finding.advisory);
  const count = body.count ?? findings.length;
  const advisory = body.advisory ?? (body.findings || []).filter((finding) => finding.advisory).length;
  const score = body.score || {};
  report.append(el('p', 'scope', `${body.source || ''} — ${body.scope || ''}`));
  report.append(el(
    'p',
    'count',
    `Risk ${score.value ?? 0} · ${score.grade || '—'} · ${count} blocking${advisory ? ` · ${advisory} AI` : ''}`,
  ));
  if (score.headline) report.append(el('p', 'why', score.headline));
  if (advisory > 0) report.append(aiPanel(body, advisory));

  if (!findings.length) {
    report.append(el('p', 'empty', 'No findings. Nothing in this scan blocks the merge.'));
  }
  for (const finding of findings.slice(0, SHOWN)) {
    const row = el('div', `row sev-${finding.severity || 'medium'}`);
    const top = el('div', 'top');
    top.append(el('b', '', finding.rule));
    top.append(el('em', `label-${finding.label || 'unclear'}`, pretty(finding.label)));
    row.append(top);
    row.append(el('span', 'where', `${finding.source} ${finding.path}:${finding.line}`));
    if (finding.masked) row.append(el('code', 'masked', finding.masked));
    const badges = badgesFor(finding);
    if (badges.length) {
      const wrap = el('div', 'badges');
      for (const badge of badges) wrap.append(el('span', badge.hot ? 'hot' : '', badge.text));
      row.append(wrap);
    }
    if (finding.why) row.append(el('p', 'why', finding.why));
    const fileUrl = githubFindingUrl(body, finding);
    if (fileUrl) {
      const link = el('a', 'file-link', 'Open file on GitHub');
      link.href = fileUrl;
      link.target = '_blank';
      link.rel = 'noreferrer';
      row.append(link);
    }
    report.append(row);
  }
  if (findings.length > SHOWN) {
    report.append(el('p', 'more', `Showing ${SHOWN} of ${findings.length}. Open the merge gate report for PDF, fixes, and Muse chat.`));
  }
  if (body.muse?.summary) {
    const box = el('div', 'muse');
    box.append(el('span', 'muse-label', `Muse · ${body.muse.provider || 'local'}${body.muse.model ? ` · ${body.muse.model}` : ''}`));
    box.append(el('p', '', body.muse.summary));
    report.append(box);
  }
  full.href = `${API_BASE}/report?url=${encodeURIComponent(url)}`;
  if (globalThis.SentinelHistory?.saveScan) {
    SentinelHistory.saveScan({
      ts: Date.now(),
      url,
      source: body.source || url,
      verdict: body.ok ? 'pass' : 'fail',
      score: score.value ?? (body.ok ? 0 : 70),
      grade: score.grade || null,
      count,
      advisory,
      headline: score.headline || body.muse?.summary || '',
      museProvider: body.muse?.provider || null,
    }).catch(() => {});
  }
}

function aiPanel(body, advisory) {
  const assessment = body.muse?.assessment || null;
  const verdict = assessment?.verdict;
  const box = el('div', 'ai');
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'ai-toggle';
  const label = `${advisory} AI signal${advisory === 1 ? '' : 's'}${verdict ? ` · ${String(verdict).replaceAll('_', ' ')}` : ''}`;
  toggle.append(el('span', '', label));
  toggle.append(el('span', 'ai-caret', '▸'));
  const open = el('div', 'ai-body');
  open.hidden = true;
  toggle.addEventListener('click', () => {
    open.hidden = !open.hidden;
    toggle.className = `ai-toggle${open.hidden ? '' : ' open'}`;
  });
  box.append(toggle);
  if (assessment) {
    open.append(el('p', 'ai-verdict', `Muse verdict: ${String(assessment.verdict || 'unclear').replaceAll('_', ' ')} (${assessment.confidence || 'low'} confidence)`));
    for (const item of assessment.evidence || []) {
      if (!item || (!item.signal && !item.why)) continue;
      const row = el('p', 'ai-evidence');
      row.append(el('b', '', item.signal || 'signal'));
      if (item.why) row.append(el('span', '', ` — ${item.why}`));
      open.append(row);
    }
    for (const focus of assessment.review_focus || []) {
      open.append(el('p', 'ai-focus', `Check: ${focus}`));
    }
    for (const note of assessment.notes || []) {
      if (note) open.append(el('p', 'ai-note', String(note)));
    }
  }
  for (const finding of (body.findings || []).filter((finding) => finding.advisory)) {
    const row = el('div', 'ai-finding');
    row.append(el('b', '', finding.rule));
    row.append(el('span', 'where', `${finding.source} ${finding.path || ''}${finding.line ? `:${finding.line}` : ''}`.trim()));
    if (finding.masked) row.append(el('code', 'masked', finding.masked));
    open.append(row);
  }
  box.append(open);
  return box;
}

async function scanUrl(url) {
  const response = await fetch(`${API_BASE}/api/scan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'The scan failed.');
  return body;
}

async function listRepo(url) {
  const response = await fetch(`${API_BASE}/api/list`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Could not list that repository.');
  return body;
}

async function runScan(targetUrl) {
  setBusy(true);
  hidePicker();
  report.hidden = true;
  foot.hidden = true;
  show('Fetching PR/commit + Muse triage (often 15–30s)…');
  try {
    const body = await scanUrl(targetUrl);
    const score = body.score?.value;
    show(body.ok
      ? `Passed${score != null ? ` · risk ${score}` : ''}.`
      : `Failed${score != null ? ` · risk ${score}` : ''}. Open full report for fixes.`);
    render(body, targetUrl);
  } catch (error) {
    state.textContent = 'Error';
    state.className = 'fail';
    const hint = /failed to fetch|networkerror|load failed/i.test(error.message || '')
      ? 'Could not reach the Sentinel backend. Try again in a moment.'
      : (error.message || 'The scan failed.');
    show(hint, 'error');
  } finally {
    setBusy(false);
    updatePickCount();
  }
}

async function runList(page) {
  setBusy(true, 'Listing…');
  report.hidden = true;
  foot.hidden = true;
  hidePicker();
  state.textContent = 'Pick';
  state.className = '';
  show(`Listing public PRs and commits for ${page.label}…`);
  try {
    const listing = await listRepo(page.repoUrl);
    show(`Select up to ${MAX_PICK} items, then scan.`);
    renderPicker(listing, page);
  } catch (error) {
    state.textContent = 'Error';
    state.className = 'fail';
    show(error.message || 'Could not list that repository.', 'error');
  } finally {
    setBusy(false);
    updatePickCount();
  }
}

async function handleTarget(raw, { auto = false } = {}) {
  const page = classifyGitHubUrl(raw);
  if (page.kind === 'none') {
    state.textContent = 'Error';
    state.className = 'fail';
    show('Use a public https://github.com/owner/repo link, a pull request, or a commit.', 'error');
    return;
  }
  urlInput.value = page.scanUrl;
  if (page.kind === 'pr' || page.kind === 'commit') {
    if (page.fromFile) show('File page pinned to a commit — scanning that commit…');
    await runScan(page.scanUrl);
    return;
  }
  // Repo home / branch file page / misc tabs → picker (never auto-scan the whole repo).
  await runList(page);
  if (auto) {
    // already showed picker
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  await handleTarget(urlInput.value.trim());
});

scanPicked.addEventListener('click', async () => {
  const urls = [...selected];
  if (!urls.length) return;
  setBusy(true);
  report.hidden = true;
  foot.hidden = true;
  let last = null;
  let fails = 0;
  try {
    for (let i = 0; i < urls.length; i += 1) {
      show(`Scanning ${i + 1}/${urls.length}…`);
      const body = await scanUrl(urls[i]);
      if (!body.ok) fails += 1;
      last = { body, url: urls[i] };
    }
    if (last) {
      show(urls.length === 1
        ? (last.body.ok ? 'Passed.' : 'Failed. Open full report for fixes.')
        : `Done · ${fails} Fail / ${urls.length - fails} Pass of ${urls.length}. Showing last result.`);
      render(last.body, last.url);
    }
  } catch (error) {
    state.textContent = 'Error';
    state.className = 'fail';
    show(error.message || 'The scan failed.', 'error');
  } finally {
    setBusy(false);
    updatePickCount();
  }
});

dash?.addEventListener('click', openDashboard);

tabUrl().then(async (value) => {
  if (!value) {
    show('Open a GitHub PR, commit, or repo tab — or paste a link.');
    return;
  }
  const page = classifyGitHubUrl(value);
  if (page.kind === 'none') {
    show('Open a GitHub PR, commit, or repo tab — or paste a link.');
    return;
  }
  urlInput.value = page.kind === 'repo' ? page.repoUrl : page.scanUrl;
  if (page.kind === 'pr' || page.kind === 'commit') {
    await handleTarget(page.scanUrl, { auto: true });
    return;
  }
  // Main repo / file-on-branch / pulls index → load picker, do not scan yet.
  await runList(page);
});
